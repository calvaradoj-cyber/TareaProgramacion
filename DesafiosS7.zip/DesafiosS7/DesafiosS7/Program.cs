﻿using System;

class Program
{
    static void Main()
    {
        char[,] t = {
            { ' ', ' ', ' ' },
            { ' ', ' ', ' ' },
            { ' ', ' ', ' ' }
        };

        char j = 'X';

        for (int k = 0; k < 9; k++)
        {
            Console.Clear();
            Console.WriteLine($"{t[0,0]}|{t[0,1]}|{t[0,2]}");
            Console.WriteLine("-+-+-");
            Console.WriteLine($"{t[1,0]}|{t[1,1]}|{t[1,2]}");
            Console.WriteLine("-+-+-");
            Console.WriteLine($"{t[2,0]}|{t[2,1]}|{t[2,2]}");

            Console.WriteLine("Turno de: " + j);

            int f, c;

            Console.Write("Fila (0-2): ");
            while (!int.TryParse(Console.ReadLine(), out f) || f < 0 || f > 2)
            {
                Console.Write("Ingresa fila válida (0-2): ");
            }

            Console.Write("Columna (0-2): ");
            while (!int.TryParse(Console.ReadLine(), out c) || c < 0 || c > 2)
            {
                Console.Write("Ingresa columna válida (0-2): ");
            }

            if (t[f, c] == ' ')
            {
                t[f, c] = j;
                j = (j == 'X') ? 'O' : 'X';
            }
            else
            {
                Console.WriteLine("Esa casilla está ocupada");
                Console.ReadKey();
                k--;
            }
        }

        Console.Clear();
        Console.WriteLine("Empate");
    }
}