﻿using System;

class Program
{
    static void Main()
    {
        string[] t = new string[10];
        int n = 0, op;

        do
        {
            Console.WriteLine("1.Mostrar 2.Agregar 3.Eliminar 0.Salir");
            int.TryParse(Console.ReadLine(), out op);

            if (op == 1)
            {
                for (int i = 0; i < n; i++)
                    Console.WriteLine((i + 1) + ". " + t[i]);
            }
            else if (op == 2)
            {
                Console.Write("Tarea: ");
                t[n++] = Console.ReadLine();
            }
            else if (op == 3)
            {
                Console.Write("Num: ");
                int x;
                int.TryParse(Console.ReadLine(), out x);

                for (int i = x - 1; i < n - 1; i++)
                    t[i] = t[i + 1];

                n--;
            }

        } while (op != 0);
    }
}