﻿using System;

class Program
{
    static void Main()
    {
        double[,] compras = {
            {50, 20, 10, 5, 5},
            {200, 150, 100, 50, 100},
            {500, 400, 200, 100, 50},
            {20, 30, 40, 10, 5},
            {1000, 200, 300, 400, 150}
        };

        CalcularDescuentos(compras);
    }

    static void CalcularDescuentos(double[,] compras)
    {
        for (int i = 0; i < compras.GetLength(0); i++)
        {
            double total = 0;

            // Sumar compras
            for (int j = 0; j < compras.GetLength(1); j++)
            {
                total += compras[i, j];
            }

            double descuento = 0;

            if (total >= 100 && total <= 1000)
                descuento = total * 0.10;
            else if (total > 1000)
                descuento = total * 0.20;

            double totalFinal = total - descuento;

            Console.WriteLine("Cliente " + (i + 1));
            Console.WriteLine("Total: " + total);
            Console.WriteLine("Descuento: " + descuento);
            Console.WriteLine("Total a pagar: " + totalFinal);
            Console.WriteLine("----------------------");
        }
    }
}