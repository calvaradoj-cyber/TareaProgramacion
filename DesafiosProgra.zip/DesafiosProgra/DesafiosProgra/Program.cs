﻿using System;

class Calculadora
{
    public string Marca;
    public string Serie;

    public double Sumar(double a, double b) => a + b;
    public double Restar(double a, double b) => a - b;
    public double Multiplicar(double a, double b) => a * b;
    public double Dividir(double a, double b) => a / b;
}

class CalculadoraCientifica : Calculadora
{
    public double Potencia(double a, double b) => Math.Pow(a, b);
    public double Raiz(double a) => Math.Sqrt(a);
    public double Modulo(double a, double b) => a % b;
    public double Logaritmo(double a) => Math.Log(a);
}

class Program
{
    static void Main()
    {
        Calculadora c = new Calculadora();
        Console.WriteLine(c.Sumar(2, 3));

        CalculadoraCientifica cc = new CalculadoraCientifica();
        Console.WriteLine(cc.Potencia(2, 3));
    }
}
