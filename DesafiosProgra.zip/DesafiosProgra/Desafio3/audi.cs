using System;

namespace Desafio3
{
    class Audi : Auto
    {
        private string marca = "Audi";

        public string Modelo { get; set; }

        public Audi(int hp, string color, string modelo) : base(hp, color)
        {
            this.Modelo = modelo;
        }

        public new void MostrarDetalles()
        {
            Console.WriteLine("Marca: {0} - Modelo: {1} - HP: {2} - Color: {3}",
                marca, Modelo, HP, Color);
        }
        
        public override void Reparar(string detalle)
        {
            Console.WriteLine("El Audi {0} fue reparado: {1}", Modelo, detalle);
        }
    }
}