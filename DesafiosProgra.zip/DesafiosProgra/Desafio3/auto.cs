using System;
using System.Collections.Generic;

namespace Desafio3
{
    class Auto
    {
        // Propiedades
        public int HP { get; set; }
        public string Color { get; set; }

        // Lista de reparaciones
        protected List<string> reparaciones = new List<string>();

        // Constructor
        public Auto(int hp, string color)
        {
            this.HP = hp;
            this.Color = color;
        }

        // Métodos
        public void MostrarDetalles()
        {
            Console.WriteLine("HP: {0} - Color: {1}", HP, Color);
        }

        public virtual void Reparar(string detalle)
        {
            reparaciones.Add(detalle);
            Console.WriteLine("Reparación guardada en memoria");
        }

        public virtual void HistoriaDeReparaciones()
        {
            Console.WriteLine("Historial (memoria):");
            foreach (var r in reparaciones)
            {
                Console.WriteLine(r);
            }
        }
    }
}