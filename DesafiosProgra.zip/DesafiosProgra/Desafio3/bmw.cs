using System;
using System.IO;

namespace Desafio3
{
    class BMW : Auto
    {
        private string marca = "BMW";

        public string Modelo { get; set; }

        public BMW(int hp, string color, string modelo) : base(hp, color)
        {
            this.Modelo = modelo;
        }

        public new void MostrarDetalles()
        {
            Console.WriteLine("Marca: {0} - Modelo: {1} - HP: {2} - Color: {3}",
                marca, Modelo, HP, Color);
        }

        public override void Reparar(string detalle)
        {
            string archivo = "reparaciones.txt";
            File.AppendAllText(archivo, detalle + Environment.NewLine);

            Console.WriteLine("Reparación guardada en archivo para BMW {0}", Modelo);
        }

        public override void HistoriaDeReparaciones()
        {
            string archivo = "reparaciones.txt";

            Console.WriteLine("Historial de reparaciones BMW:");

            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);

                foreach (var l in lineas)
                {
                    Console.WriteLine(l);
                }
            }
            else
            {
                Console.WriteLine("No hay reparaciones registradas.");
            }
        }
    }
}