﻿using System;

// Interfaz
interface INotificable
{
    void Notificar();
}

// Implementación Email
class NotificacionEmail : INotificable
{
    public string direccionCorreo;

    public void Notificar()
    {
        Console.WriteLine("Enviando email a: " + direccionCorreo);
    }
}

// Implementación WhatsApp
class NotificacionWhatsApp : INotificable
{
    public string numeroTelefono;

    public void Notificar()
    {
        Console.WriteLine("Enviando WhatsApp a: " + numeroTelefono);
    }
}

// Implementación SMS
class NotificacionSMS : INotificable
{
    public string numeroTelefono;

    public void Notificar()
    {
        Console.WriteLine("Enviando SMS a: " + numeroTelefono);
    }
}

// Main
class Program
{
    static void Main()
    {
        NotificacionEmail email = new NotificacionEmail();
        email.direccionCorreo = "correo@gmail.com";
        email.Notificar();

        NotificacionWhatsApp whatsapp = new NotificacionWhatsApp();
        whatsapp.numeroTelefono = "12345678";
        whatsapp.Notificar();

        NotificacionSMS sms = new NotificacionSMS();
        sms.numeroTelefono = "87654321";
        sms.Notificar();
    }
}